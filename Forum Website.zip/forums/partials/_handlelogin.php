<?php
$showError = "false";
if ($_SERVER['REQUEST_METHOD'] == "POST"){
    include '_dbconnect.php';
    $email = $_POST['loginemail']; 
    $pass = $_POST['loginpassword']; 

    $sql = "SELECT * FROM `users` WHERE user_email = '$email'";
    $result = mysqli_query($conn, $sql);

    $numRows = mysqli_num_rows($result);
    if ($numRows == 1) {
        # code...
        $row = mysqli_fetch_assoc($result);
        if (password_verify($pass , $row['user_pw'])) {
            # code...
            session_start();
            $_SESSION['loggedin']=true;
            $_SESSION['srno']=$row['srno'];
            $_SESSION['useremail']=$email; 
            echo"Loggedin".$email;
        }
    
        header("location:/forums/index.php");

    }
    header("location:/forums/index.php");
        
}
 ?>