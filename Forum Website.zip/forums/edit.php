     mj m  hyyjuu bh n nnn nnn   
       